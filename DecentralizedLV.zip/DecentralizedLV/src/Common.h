#pragma once
// One include for every feature file: HAL + config + the vehicle's board objects.
// Features include this as  #include "../Common.h"
#include "hal/Hal.h"
#include "config/Config.h"
#include "config/Colors.h"
#include "config/Pins.h"
#include "vehicle/Vehicle.h"
