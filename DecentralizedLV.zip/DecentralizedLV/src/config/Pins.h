#pragma once
// Select the pin map for the board being built. Add an #elif for each new board.
#define BOARD_PHOTON_DASH 1

#if BOARD_PHOTON_DASH
  #include "PinMap_PhotonDash.h"
#else
  #error "Select a board pin map in config/Pins.h"
#endif
