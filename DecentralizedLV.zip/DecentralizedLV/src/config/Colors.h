#pragma once
#include <stdint.h>
// All colours in one place (0xRRGGBB).
constexpr uint32_t COLOR_BLUE   = 0x0000FF;
constexpr uint32_t COLOR_RED    = 0xFF0000;
constexpr uint32_t COLOR_GREEN  = 0x00FF00;
constexpr uint32_t COLOR_YELLOW = 0xFF4500;   //Warm orange (used for blinkers)
constexpr uint32_t COLOR_CYAN   = 0x008080;
constexpr uint32_t COLOR_PURPLE = 0x800080;
constexpr uint32_t COLOR_WHITE  = 0x808080;
constexpr uint32_t COLOR_DIM    = 0x0A0A0A;
