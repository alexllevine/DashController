#pragma once
// Documentation of legacy CAN frames (not currently decoded here - the DecentralizedLV-Boards
// library classes parse the live frames). Kept as the reference for the byte layouts.
#define CAN_MAIN_COMP   0x110   //Main telemetry computer
// byte 2: RMS RPM (lower byte), byte 3: RMS RPM (upper byte)
#define CAN_RMS_COMP    0x116   //Main telemetry computer: motor controller + BMS data
// byte 0: RMS Temp (C), byte 1: Motor Temp (C), byte 2: Battery Temp (C), byte 3: Battery %
