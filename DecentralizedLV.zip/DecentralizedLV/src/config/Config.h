#pragma once
/*
 * Config.h - EVERY tunable/feature flag lives here. Nothing else needs editing for simple tweaks.
 * (Pin assignments are in Pins.h / PinMap_*.h, colours in Colors.h, CAN IDs in CanIds.h)
 */

//////////////////////////////////////////////////
/////////////    SYSTEM BEHAVIOR    //////////////
//////////////////////////////////////////////////
#define DO_LOW_POWER_MODE       false   //Enable low power mode based on signals from the power controller.
#define DO_RMS_FAN_CONTROL      false   //true: radiator fan speed follows motor temp from the RMS. false: fan on with Ignition
#define DO_BMS_FAN_CONTROL      false   //true: fan speed follows HV battery temp from the BMS. false: fan on with Ignition
#define DO_ANALOG_DRIVE_SW      false   //true: drive switch is a resistor network (sport/eco/...). false: simple binary switch
#define DO_ANALOG_LIGHT_SW      false   //true: headlight switch is a resistor network (headlight/high beam). false: binary switch
#define DO_SOUNDBOARD_HORN      false   //true: YX6300 soundboard is the horn. false: switch drives a corner board
#define DO_NEOPIXELS            true    //true: a neopixel strip is attached (12V->5V regulator) and animated
#define DO_MOMENTARY_FAN        false   //true: momentary push button for driver fan, false: on/off switch
#define DRV_FAN_INIT_MODE       false   //Default state of driver fan when going to accessory

#define LOOP_PERIOD_MS          10      //Main loop period (every module runs once per period)
#define CAN_BAUD_RATE           500000  //CAN bus speed

//////////////////////////////////////////////////
/////////////    LED STRIP CONFIG   //////////////
//////////////////////////////////////////////////
#define LED_STRIP_COUNT         100     //Total number of LEDs in the WS2815 strip
#define LED_STEERING_COLUMN     27      //Pixel position of steering column (centered on dash)
#define LED_LEFT_TURN_COUNT     11      //Pixels for left turn signal
#define LED_RIGHT_TURN_COUNT    11      //Pixels for right turn signal
#define LED_LEFT_TURN_START     (LED_STEERING_COLUMN - LED_LEFT_TURN_COUNT)
#define LED_RIGHT_TURN_START    (LED_STEERING_COLUMN)
#define LED_STATE_INDICATOR_COUNT   8   //First 8 LEDs show ready-to-drive / fault state
#define LED_LOW_BEAM_INDEX      10      //LED index for low beam indicator (0-indexed)
#define LED_HIGH_BEAM_INDEX     13      //LED index for high beam indicator (0-indexed)
#define LED_UPDATE_PERIOD_MS    50      //Strip refresh period
#define LED_TRANSITION_MS       1000    //Duration when changing state colours/brightness (reserved)
#define USE_SIDE_INDICATORS     true    //true if using side indicator lights

// Acceleration-based twinkle (responds to current draw)
#define TWINKLE_ACCEL_MAX_AMPS      250.0f
#define TWINKLE_ACCEL_MIN_AMPS      10.0f
#define TWINKLE_ACCEL_MAX_LEDS      20
#define TWINKLE_ACCEL_DURATION_MS   150
#define TWINKLE_ACCEL_BRIGHTNESS    255
// Static driving twinkle (ambient effect when moving)
#define TWINKLE_STATIC_SPEED_MPH    1.0f
#define TWINKLE_STATIC_FREQUENCY_MS 2000
#define TWINKLE_STATIC_MAX_LEDS     5
#define TWINKLE_STATIC_DURATION_MS  800
#define TWINKLE_STATIC_FADE_MS      400
#define TWINKLE_STATIC_BRIGHTNESS   200

//////////////////////////////////////////////////
///////////  SOUND SYSTEM CONFIG   ///////////////
//////////////////////////////////////////////////
// Sound file indices on SD card (001.mp3, 002.mp3, ...)
#define SOUND_CHARGER           1
#define SOUND_FAULT             2
#define SOUND_HORN              3
#define SOUND_POWER_OFF         4
#define SOUND_POWER_ON          5
#define SOUND_REVERSE           6
// Volume per sound (0-30)
#define SOUND_VOL_CHARGER       25
#define SOUND_VOL_FAULT         30
#define SOUND_VOL_HORN          30
#define SOUND_VOL_POWER_OFF     20
#define SOUND_VOL_POWER_ON      20
#define SOUND_VOL_REVERSE       18
#define SOUND_STARTUP_DELAY_MS  500     //Wait this long after soundboard init before playing anything

//////////////////////////////////////////////////
/////////  THRESHOLDS / COOLING / LIGHTS  ////////
//////////////////////////////////////////////////
#define AUTO_HDL_OFF            1000    //Auto headlights: photoresistor below this turns lights off (keep > AUTO_HDL_ON for hysteresis)
#define AUTO_HDL_ON             600     //Auto headlights: photoresistor above this turns lights on

#define SPEEDTHR        10
#define MTR_TEMP_THR    60              //Motor temp (C) that enables radiator/motor fan
#define MTR_LPM_OFFSET  10              //Offset (C) for fan enable in low power mode
#define BATT_TEMP_THR   35
#define RAD_FAN_TEMP_ON   50            //C - radiator fan begins spinning
#define RAD_FAN_TEMP_FULL 80            //C - radiator fan at full speed

//analogRead thresholds for drive mode and headlight switches (set from resistor network values)
#define DRV_ECO_THR     1000
#define DRV_SPT_THR     2000
#define DRV_NRM_THR     3000
#define HDL_AUTO_THR    1000
#define HDL_HBM_THR     2000
#define HDL_MANU_THR    3000

//////////////////////////////////////////////////
//////////// SIDE INDICATOR CONFIG ///////////////
//////////////////////////////////////////////////
#define TURN_SIGNAL_RATE_PPM        90  //Pulses Per Minute (60-120 typical)
#define TURN_SIGNAL_HALF_PERIOD_MS (60000/TURN_SIGNAL_RATE_PPM)
#define FAULT_FLASH_PERIOD_MS       666 //~90 pulses/min, used by every fault strobe
