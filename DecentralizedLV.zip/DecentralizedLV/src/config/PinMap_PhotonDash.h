#pragma once
/*
 * Pin map for the Photon-based Dash Controller board.
 * To support another board: copy this file, change the right-hand sides, and select it in Pins.h.
 * Feature code only ever uses the LOGICAL names on the left.
 */
//////////////  INPUT SWITCHES  //////////////
#define HEADLIGHT   A1   //Headlight switch (analog for auto/manual, or binary)
#define DRV_SW      A2   //Drive mode switch
#define HORN_SW     D0   //Horn button (momentary)
#define HIGHBEAM    D3   //High beam switch
#define LTURN       D4   //Left turn stalk (from blinker timer)
#define RTURN       D5   //Right turn stalk
#define REV_SW      D6   //Reverse switch
#define HAZARD_SW   D7   //Hazard button (momentary)
//////////////  LOW-POWER OUTPUTS (P-MOSFET)  //////////////
#define IPAD_CHARGER A3  //12V iPad/cig-lighter charger
#define TELEMETRY    A0  //12V telemetry radio
#define RADIO        A7  //12V ham/comms radio
#define WIPER        A5  //12V windshield wiper
//////////////  MISC  //////////////
#define LIGHT_SENSE  A4  //Ambient light photoresistor (ADC)
#define NEOPIX_DATA  A6  //Neopixel data out
