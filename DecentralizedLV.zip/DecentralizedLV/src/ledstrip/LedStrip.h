#pragma once
/*
 * LedStrip - interior/dash neopixel strip. Public face of the ledstrip/ folder.
 * Render priority each frame (first match wins):  light show  >  charging  >  normal
 * Sub-renderers: LedShowRender.cpp, LedCharging.cpp, LedTwinkle.cpp, helpers in LedUtil.cpp.
 * Compiles to empty stubs when DO_NEOPIXELS is false.
 */
namespace ledStrip {
    void init();
    void update();
}
