#include "../Common.h"
#include "LedInternal.h"
#include <math.h>
#if DO_NEOPIXELS

namespace {
    struct LEDTwinkle {
        uint32_t startTime;   //When this twinkle started (millis)
        uint16_t duration;    //Total duration (ms)
        uint32_t baseColor;   //Original colour to fade from/to
        bool     active;      //Currently twinkling
    };
    LEDTwinkle twinkles[LED_STRIP_COUNT];
    uint32_t lastStaticTwinkle = 0;   //Last time the ambient twinkle was triggered

    // Acceleration twinkle: more LEDs the harder the pack is working
    void triggerAcceleration(float currentAmps){
        float ratio = (currentAmps - TWINKLE_ACCEL_MIN_AMPS) / (TWINKLE_ACCEL_MAX_AMPS - TWINKLE_ACCEL_MIN_AMPS);
        if(ratio > 1.0f) ratio = 1.0f;
        if(ratio < 0.0f) ratio = 0.0f;

        uint8_t numLEDs = (uint8_t)(ratio * TWINKLE_ACCEL_MAX_LEDS);
        if(numLEDs == 0 && currentAmps >= TWINKLE_ACCEL_MIN_AMPS) numLEDs = 1;   //at least one

        for(uint8_t i = 0; i < numLEDs; i++){
            uint16_t idx = hal::random(LED_STRIP_COUNT);
            if(!twinkles[idx].active){   //don't re-trigger
                twinkles[idx].active = true;
                twinkles[idx].startTime = hal::millis();
                twinkles[idx].duration = TWINKLE_ACCEL_DURATION_MS;
                twinkles[idx].baseColor = hal::strip::getPixel(idx);
            }
        }
    }

    // Ambient twinkle while driving
    void triggerStatic(){
        uint8_t numLEDs = hal::random(1, TWINKLE_STATIC_MAX_LEDS + 1);
        for(uint8_t i = 0; i < numLEDs; i++){
            uint16_t idx = hal::random(LED_STRIP_COUNT);
            if(!twinkles[idx].active){
                twinkles[idx].active = true;
                twinkles[idx].startTime = hal::millis();
                twinkles[idx].duration = TWINKLE_STATIC_DURATION_MS;
                twinkles[idx].baseColor = hal::strip::getPixel(idx);
            }
        }
    }

    // Fade base -> white -> base over the twinkle's duration
    void applyToLED(uint16_t idx){
        uint32_t elapsed = hal::millis() - twinkles[idx].startTime;

        if(elapsed >= twinkles[idx].duration){
            twinkles[idx].active = false;
            return;
        }

        uint8_t fadeValue;
        uint16_t half = twinkles[idx].duration / 2;
        if(elapsed < half) fadeValue = (elapsed * 255) / half;                 //fade to white
        else               fadeValue = 255 - ((elapsed - half) * 255) / half;  //fade back

        //Max brightness depends on twinkle type
        uint8_t maxBrightness = (twinkles[idx].duration == TWINKLE_ACCEL_DURATION_MS)
                                ? TWINKLE_ACCEL_BRIGHTNESS : TWINKLE_STATIC_BRIGHTNESS;
        fadeValue = (fadeValue * maxBrightness) / 255;

        uint32_t c = ledUtil::blend(twinkles[idx].baseColor, COLOR_WHITE, fadeValue);
        hal::strip::setPixel(idx, (c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF);
    }
}

namespace ledTwinkle {

void init(){
    for(uint16_t i = 0; i < LED_STRIP_COUNT; i++){
        twinkles[i].active = false;
        twinkles[i].startTime = 0;
        twinkles[i].duration = 0;
        twinkles[i].baseColor = 0;
    }
    lastStaticTwinkle = hal::millis();
}

void update(){
    float currentAmps = fabsf(bms.packCurrentAmps);   //discharge or charge
    float speedMPH = instrumentCluster.speedGauge;

    if(currentAmps >= TWINKLE_ACCEL_MIN_AMPS) triggerAcceleration(currentAmps);

    if(speedMPH >= TWINKLE_STATIC_SPEED_MPH){
        if(hal::millis() - lastStaticTwinkle >= TWINKLE_STATIC_FREQUENCY_MS){
            triggerStatic();
            lastStaticTwinkle = hal::millis();
        }
    }

    //Overlay active twinkles on top of the base colours
    for(uint16_t i = 0; i < LED_STRIP_COUNT; i++)
        if(twinkles[i].active) applyToLED(i);
}

}
#endif
