#include "../Common.h"
#include "LedInternal.h"
#include <math.h>
#if DO_NEOPIXELS

namespace {
    uint32_t chargingAnimStart = 0;          //When the charging animation cycle started (0 = not charging)
    uint16_t chargingAnimWidth = 20;         //LEDs in the moving highlight
    uint16_t chargingAnimDuration = 700;     //ms for a full left->right sweep
    uint8_t  chargingBaseBrightness = 80;    //Base brightness of charged LEDs (dim so highlight pops)
    uint8_t  chargingOverlayBrightness = 255;//Peak brightness of the moving overlay
}

namespace ledCharging {

bool render(bool faultPresent, bool faultFlash){
    float packCurrent = bms.packCurrentAmps;   //negative = charging
    if(!(packCurrent < 0.0f)){
        chargingAnimStart = 0;                 //reset animation when not charging
        return false;
    }

    if(chargingAnimStart == 0) chargingAnimStart = hal::millis();

    //LEDs lit for state of charge (left -> right)
    uint16_t litCount = (uint16_t)((uint32_t)bms.packSOC * (uint32_t)LED_STRIP_COUNT / 100U);
    if(litCount > LED_STRIP_COUNT) litCount = LED_STRIP_COUNT;

    //Moving highlight position (0..litCount-1)
    uint32_t t = hal::millis() - chargingAnimStart;
    float progress = (chargingAnimDuration == 0) ? 0.0f : (float)(t % chargingAnimDuration) / (float)chargingAnimDuration;
    float pos = (litCount == 0) ? 0.0f : progress * (float)(litCount - 1);
    float halfWidth = (float)chargingAnimWidth / 2.0f;

    // A charging fault must be unmistakable: keep the SOC/bar motion but make it red instead of green.
    uint32_t chargeColor = faultPresent ? COLOR_RED : COLOR_GREEN;
    uint8_t baseR = (chargeColor >> 16) & 0xFF;
    uint8_t baseG = (chargeColor >> 8) & 0xFF;
    uint8_t baseB = chargeColor & 0xFF;

    for(uint16_t i = 0; i < LED_STRIP_COUNT; i++){
        // Fault indicator always wins over the charging animation (first LED_STATE_INDICATOR_COUNT LEDs)
        if(faultPresent && i < LED_STATE_INDICATOR_COUNT){
            if(faultFlash) hal::strip::setPixel(i, 255, 0, 0);
            else           hal::strip::setPixel(i, 0, 0, 0);
        }
        else if(i < litCount){
            uint8_t baseBrightness = chargingBaseBrightness;

            //Overlay brightness by distance from moving position
            float dist = fabsf((float)i - pos);
            float overlayFactor = 0.0f;
            if(dist <= halfWidth && halfWidth > 0.0f){
                overlayFactor = 1.0f - (dist / halfWidth);   //1.0 at center -> 0 at edges
            }
            uint16_t overlay = (uint16_t)(overlayFactor * (float)chargingOverlayBrightness);

            uint16_t totalBright = (uint16_t)baseBrightness + overlay;
            if(totalBright > 255) totalBright = 255;

            uint8_t r = (baseR * totalBright) / 255;
            uint8_t g = (baseG * totalBright) / 255;
            uint8_t b = (baseB * totalBright) / 255;
            hal::strip::setPixel(i, r, g, b);
        }
        else{
            hal::strip::setPixel(i, 0, 0, 0);   //not charged yet
        }
    }

    // Beam dots are status indicators, not part of the bar: drawn last so nothing can hide them.
    ledUtil::drawBeamIndicators();

    hal::strip::show();
    return true;
}

}
#endif
