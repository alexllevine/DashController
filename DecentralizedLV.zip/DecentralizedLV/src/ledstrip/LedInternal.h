#pragma once
#include <stdint.h>
// Shared by the ledstrip/*.cpp files only. Feature code outside this folder should not include it.

namespace ledUtil {
    // Set `count` pixels from `start` to a colour scaled by brightness (0-255)
    void setZone(uint16_t start, uint16_t count, uint32_t color, uint8_t brightness = 255);
    // Colour for current power state (blue=driving, red=ign, green=acc, white=off)
    uint32_t stateColor();
    // Blend color1->color2 (0 = color1, 255 = color2)
    uint32_t blend(uint32_t color1, uint32_t color2, uint8_t amount);
    // Low/high beam status dots - ALWAYS drawn last so no effect can hide them
    void drawBeamIndicators();
}

namespace ledCharging {
    // If the pack is charging, draws the SOC bar + moving highlight and returns true (frame fully done).
    // Otherwise resets its animation and returns false.
    bool render(bool faultPresent, bool faultFlash);
}

namespace ledTwinkle {
    void init();
    void update();     //Trigger new twinkles from current draw / speed, then overlay active ones
}

void renderShowInterior();   //Light-show frame (LedShowRender.cpp)
