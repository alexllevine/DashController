#include "../Common.h"
#include "LedInternal.h"
#include "../features/LightShow.h"
#include "../features/Faults.h"
#if DO_NEOPIXELS

// Render the interior strip from the latest light-show cue (SHOW_ZONE_INTERIOR). Effects are spatial
// (chases, centre-out ripples, theatre patterns, glitter), not just whole-strip colour changes.
// Integer-only math so rendering stays well inside the LED refresh budget.
void renderShowInterior(){
    const lightShow::CueState& cue = lightShow::interior();

    //Base cue colour scaled by cue intensity (0-255)
    uint16_t inten = cue.intensity;
    uint8_t baseR = (uint16_t)cue.r * inten / 255;
    uint8_t baseG = (uint16_t)cue.g * inten / 255;
    uint8_t baseB = (uint16_t)cue.b * inten / 255;

    uint32_t sinceCue = hal::millis() - lightShow::interiorCueMs();
    switch(cue.effect){
        case SHOW_FX_PULSE: {
            //Bright centre hit expands into the dash and fades over 450 ms
            const uint32_t decayMs = 450;
            uint16_t decay = (sinceCue >= decayMs) ? 0 : (uint16_t)(255 - (sinceCue * 255 / decayMs));
            uint16_t expandingRadius = 4 + ((sinceCue * (LED_STRIP_COUNT / 2)) / decayMs);
            for(uint16_t i = 0; i < LED_STRIP_COUNT; i++){
                uint16_t distance = (i > LED_STEERING_COLUMN) ? i - LED_STEERING_COLUMN : LED_STEERING_COLUMN - i;
                uint16_t falloff = (distance >= expandingRadius) ? 0 : (uint16_t)(255 - (distance * 255 / expandingRadius));
                //Faint colour wash behind the hit so it reads as a pulse, not a flicker
                uint16_t k = (uint16_t)decay * (48 + (falloff * 207 / 255)) / 255;
                hal::strip::setPixel(i, (uint16_t)baseR * k / 255, (uint16_t)baseG * k / 255, (uint16_t)baseB * k / 255);
            }
            break;
        }
        case SHOW_FX_STROBE: {
            //Alternating bars so a strobe looks dynamic instead of like a bad connection
            bool on = ((hal::millis() / 60) % 2) == 0;
            for(uint16_t i = 0; i < LED_STRIP_COUNT; i++){
                bool barOn = ((i / 5) % 2) == 0;
                if(on && barOn) hal::strip::setPixel(i, baseR, baseG, baseB);
                else            hal::strip::setPixel(i, 0, 0, 0);
            }
            break;
        }
        case SHOW_FX_SWEEP: {
            //Lit band ~1/5 of the strip runs left->right, wrapping, ~1 s period
            const uint16_t bandW = (LED_STRIP_COUNT / 5) + 1;
            float phase = (float)(hal::millis() % 1000) / 1000.0f;
            int center = (int)(phase * LED_STRIP_COUNT);
            for(uint16_t i = 0; i < LED_STRIP_COUNT; i++){
                int d = (int)i - center;
                if(d < -(int)LED_STRIP_COUNT/2) d += LED_STRIP_COUNT;
                if(d >  (int)LED_STRIP_COUNT/2) d -= LED_STRIP_COUNT;
                uint16_t ad = (d < 0) ? -d : d;
                uint16_t k = (ad >= bandW) ? 0 : (uint16_t)(255 - (ad * 255 / bandW));
                hal::strip::setPixel(i, (uint16_t)baseR*k/255, (uint16_t)baseG*k/255, (uint16_t)baseB*k/255);
            }
            break;
        }
        case SHOW_FX_CHASE: {
            //Three narrow comet heads circulate across the dash. Great for fast passages.
            const uint16_t spacing = 24;
            const uint16_t tail = 9;
            uint16_t travel = (hal::millis() / 24) % spacing;
            for(uint16_t i = 0; i < LED_STRIP_COUNT; i++){
                uint16_t position = (i + spacing - travel) % spacing;
                uint16_t k = (position < tail) ? (uint16_t)(255 - (position * 255 / tail)) : 12;
                hal::strip::setPixel(i, (uint16_t)baseR * k / 255, (uint16_t)baseG * k / 255, (uint16_t)baseB * k / 255);
            }
            break;
        }
        case SHOW_FX_RIPPLE: {
            //Concentric rings run outward from the steering-column centre and wrap back in
            const uint16_t ringSpacing = 16;
            const uint16_t ringWidth = 5;
            uint16_t travel = (hal::millis() / 22) % ringSpacing;
            for(uint16_t i = 0; i < LED_STRIP_COUNT; i++){
                uint16_t distance = (i > LED_STEERING_COLUMN) ? i - LED_STEERING_COLUMN : LED_STEERING_COLUMN - i;
                uint16_t phase = (distance + ringSpacing - travel) % ringSpacing;
                uint16_t k = (phase < ringWidth) ? (uint16_t)(255 - (phase * 255 / ringWidth)) : 18;
                hal::strip::setPixel(i, (uint16_t)baseR * k / 255, (uint16_t)baseG * k / 255, (uint16_t)baseB * k / 255);
            }
            break;
        }
        case SHOW_FX_THEATER_CHASE: {
            //Classic theatre-chase groups advance together over a dim colour underlay
            uint8_t phase = (hal::millis() / 95) % 3;
            for(uint16_t i = 0; i < LED_STRIP_COUNT; i++){
                uint16_t k = ((i + phase) % 3 == 0) ? 255 : 24;
                hal::strip::setPixel(i, (uint16_t)baseR * k / 255, (uint16_t)baseG * k / 255, (uint16_t)baseB * k / 255);
            }
            break;
        }
        case SHOW_FX_SPARKLE: {
            //Deterministic pseudo-random glitter: no random() dependency, repeatable in video
            uint16_t frame = hal::millis() / 65;
            for(uint16_t i = 0; i < LED_STRIP_COUNT; i++){
                uint16_t hash = (uint16_t)(i * 37U + frame * 17U + lightShow::interiorCueMs()) % 29U;
                uint16_t k = (hash < 3) ? 255 : 34;
                hal::strip::setPixel(i, (uint16_t)baseR * k / 255, (uint16_t)baseG * k / 255, (uint16_t)baseB * k / 255);
            }
            break;
        }
        case SHOW_FX_SOLID:
        default:
            for(uint16_t i = 0; i < LED_STRIP_COUNT; i++) hal::strip::setPixel(i, baseR, baseG, baseB);
            break;
    }

    //Safety: a real BPS/system fault still strobes the first indicator LEDs red over the show
    if(faults::bps() && (hal::millis() % FAULT_FLASH_PERIOD_MS < FAULT_FLASH_PERIOD_MS / 2)){
        for(uint16_t i = 0; i < LED_STATE_INDICATOR_COUNT && i < LED_STRIP_COUNT; i++){
            hal::strip::setPixel(i, 255, 0, 0);
        }
    }

    //Beam-status dots are safety info: keep them above every full-strip effect
    ledUtil::drawBeamIndicators();

    hal::strip::show();
}
#endif
