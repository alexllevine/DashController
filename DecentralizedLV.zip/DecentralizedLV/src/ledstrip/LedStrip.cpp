#include "LedStrip.h"
#include "LedInternal.h"
#include "../Common.h"
#include "../features/Faults.h"
#include "../features/LightShow.h"

#if DO_NEOPIXELS

namespace {
    uint32_t ledAnimationTimer = 0;   //Last strip refresh

    // Reserved for smooth state-colour transitions (LED_TRANSITION_MS). Initialised, not yet rendered.
    uint32_t ledPrevStateColor = COLOR_WHITE, ledCurStateColor = COLOR_WHITE, ledTargetStateColor = COLOR_WHITE;
    uint8_t  ledPrevBrightness = 255, ledCurBrightness = 255, ledTargetBrightness = 255;

    // Gamma-correct an app-requested brightness (0..255) so the app's evenly spaced steps look evenly
    // spaced. setBrightness is ~linear in PWM duty, so 60/80/100% look almost identical; gamma ~2 spreads
    // them. Integer math only (no powf). Endpoints preserved: 0 = OFF, 255 = full.
    uint8_t ledStripGamma(uint8_t requested){
        return (uint8_t)(((uint16_t)requested * requested) / 255);
    }

    // Normal frame:  [0..7] fault/ready indicator | gap | blinker box (centre) | fade to end in state colour
    void renderNormal(bool faultPresent, bool faultFlash){
        // Left: solid green normally, flashing red while any fault is present
        if(faultPresent) ledUtil::setZone(0, LED_STATE_INDICATOR_COUNT, COLOR_RED, faultFlash ? 255 : 0);
        else             ledUtil::setZone(0, LED_STATE_INDICATOR_COUNT, COLOR_GREEN, 255);

        // Clear the gap between state indicator and left blinker (except beam indicator LEDs)
        if(LED_STATE_INDICATOR_COUNT < LED_LEFT_TURN_START){
            for(uint16_t i = LED_STATE_INDICATOR_COUNT; i < LED_LEFT_TURN_START; i++){
                if(i != LED_LOW_BEAM_INDEX && i != LED_HIGH_BEAM_INDEX) hal::strip::setPixel(i, 0, 0, 0);
            }
        }

        // Blinker box: dashController PWM values already reflect flashing
        ledUtil::setZone(LED_LEFT_TURN_START,  LED_LEFT_TURN_COUNT,  COLOR_YELLOW, dashController.leftTurnPWM);
        ledUtil::setZone(LED_RIGHT_TURN_START, LED_RIGHT_TURN_COUNT, COLOR_YELLOW, dashController.rightTurnPWM);

        // Beam dots after blinkers to guarantee visibility
        ledUtil::drawBeamIndicators();

        // Right: linear fade to end of strip in state colour (red + 50% dimmer on fault so the flashing
        // indicator stays the strongest element)
        uint16_t rightSectionStart = LED_RIGHT_TURN_START + LED_RIGHT_TURN_COUNT;
        uint16_t rightSectionCount = 0;
        if(rightSectionStart < LED_STRIP_COUNT) rightSectionCount = LED_STRIP_COUNT - rightSectionStart;

        if(rightSectionCount > 0){
            uint32_t baseColor = faultPresent ? COLOR_RED : ledUtil::stateColor();
            for(uint16_t pos = 0; pos < rightSectionCount; pos++){
                uint16_t idx = rightSectionStart + pos;
                float scale = (rightSectionCount == 1) ? 1.0f : (float)pos / (float)(rightSectionCount - 1);
                uint8_t b = (uint8_t)(scale * 255.0f);
                if(faultPresent) b = b / 2;
                ledUtil::setZone(idx, 1, baseColor, b);
            }
        }

        // Twinkles overlay on top of the base colours
        ledTwinkle::update();

        hal::strip::show();
    }
}

namespace ledStrip {

void init(){
    hal::strip::begin(LED_STRIP_COUNT, NEOPIX_DATA);
    hal::strip::setBrightness(255);
    hal::strip::clear();
    hal::strip::show();
    ledAnimationTimer = hal::millis();

    ledCurStateColor = ledUtil::stateColor();
    ledPrevStateColor = ledCurStateColor;
    ledTargetStateColor = ledCurStateColor;
    ledCurBrightness = 255;
    ledPrevBrightness = 255;
    ledTargetBrightness = 255;

    ledTwinkle::init();
}

void update(){
    if(hal::millis() - ledAnimationTimer < LED_UPDATE_PERIOD_MS) return;
    ledAnimationTimer = hal::millis();

    // App-controlled night-time dimmer (0 = OFF/moon button .. 255 = full). Defaults to 255 on power-up.
    // Applies globally, so it dims the light show too.
    hal::strip::setBrightness(ledStripGamma(appController.ledStripBrightness));

    // 1) Music light show takes over the whole strip (fails safe via lightShow::active() timeout)
    if(lightShow::active()){
        renderShowInterior();
        return;
    }

    // Fault state is computed once so it takes priority over every effect, including charging.
    bool faultPresent = faults::bps();
    bool faultFlash = hal::millis() % FAULT_FLASH_PERIOD_MS < FAULT_FLASH_PERIOD_MS / 2;   //~90 pulses/min

    // 2) Charging override (SOC bar + moving highlight)
    if(ledCharging::render(faultPresent, faultFlash)) return;

    // 3) Normal render
    renderNormal(faultPresent, faultFlash);
}

}

#else  // DO_NEOPIXELS == false: feature compiled out
namespace ledStrip { void init(){} void update(){} }
#endif
