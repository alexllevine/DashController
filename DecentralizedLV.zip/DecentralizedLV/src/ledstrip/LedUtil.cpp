#include "../Common.h"
#include "LedInternal.h"
#if DO_NEOPIXELS

namespace ledUtil {

void setZone(uint16_t start, uint16_t count, uint32_t color, uint8_t brightness){
    uint8_t r = (color >> 16) & 0xFF;
    uint8_t g = (color >> 8) & 0xFF;
    uint8_t b = color & 0xFF;

    r = (r * brightness) / 255;
    g = (g * brightness) / 255;
    b = (b * brightness) / 255;

    for(uint16_t i = start; i < start + count && i < LED_STRIP_COUNT; i++){
        hal::strip::setPixel(i, r, g, b);
    }
}

uint32_t stateColor(){
    if(powerController.FullStart)    return COLOR_BLUE;    //Fully started
    else if(powerController.Ign)     return COLOR_RED;     //Ignition on
    else if(powerController.Acc)     return COLOR_GREEN;   //Accessory
    else                             return COLOR_WHITE;   //Off/standby
}

uint32_t blend(uint32_t color1, uint32_t color2, uint8_t amount){
    uint8_t r1 = (color1 >> 16) & 0xFF, g1 = (color1 >> 8) & 0xFF, b1 = color1 & 0xFF;
    uint8_t r2 = (color2 >> 16) & 0xFF, g2 = (color2 >> 8) & 0xFF, b2 = color2 & 0xFF;

    uint8_t r = r1 + ((r2 - r1) * amount) / 255;
    uint8_t g = g1 + ((g2 - g1) * amount) / 255;
    uint8_t b = b1 + ((b2 - b1) * amount) / 255;

    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | b;
}

void drawBeamIndicators(){
    if(dashController.headlight) setZone(LED_LOW_BEAM_INDEX, 1, COLOR_WHITE, 255);
    else hal::strip::setPixel(LED_LOW_BEAM_INDEX, 0, 0, 0);
    if(dashController.highbeam) setZone(LED_HIGH_BEAM_INDEX, 1, COLOR_WHITE, 255);
    else hal::strip::setPixel(LED_HIGH_BEAM_INDEX, 0, 0, 0);
}

}
#endif
