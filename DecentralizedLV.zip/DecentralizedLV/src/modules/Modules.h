#pragma once
namespace modules {
    void initAll();     //Call every module's init() in table order (once, from setup)
    void updateAll();   //Call every module's update() in table order (every loop)
}
