/*
 * Modules.cpp - THE registry. One row per feature. Row ORDER = execution order every loop.
 *
 * To add a feature:
 *   1. Create features/MyFeature.h/.cpp with  namespace myFeature { void init(); void update(); }
 *   2. #include it below and add one row to kModules.   (init or update may be nullptr)
 * To disable a feature: comment out its row.
 */
#include "Modules.h"
#include "../features/Inputs.h"
#include "../features/Gear.h"
#include "../features/Lights.h"
#include "../features/RunningLights.h"
#include "../features/SideIndicators.h"
#include "../features/Cooling.h"
#include "../features/LpOutputs.h"
#include "../features/SoundEffects.h"
#include "../features/StatusIndicator.h"
#include "../features/Faults.h"
#include "../features/LightShow.h"
#include "../features/CanRx.h"
#include "../features/CanTx.h"
#include "../features/Cluster.h"
#include "../ledstrip/LedStrip.h"
#include "../vehicle/Vehicle.h"

namespace {

struct Module {
    const char* name;
    void (*init)();     //runs once at boot (nullptr = none)
    void (*update)();   //runs every loop  (nullptr = none)
};

const Module kModules[] = {
    //  name              init                     update
    { "vehicle",        vehicle::init,           nullptr                       }, //CAN bus + board objects (must be first)
    { "inputs",         inputs::init,            inputs::update                }, //read switches/ADC
    { "gear",           nullptr,                 gear::update                  }, //drive mode from switches
    { "lights",         nullptr,                 lights::update                }, //headlight/highbeam/turn/hazard/horn
    { "runningLights",  runningLights::init,     runningLights::update         }, //persisted running-lights pref
    { "sideIndicators", nullptr,                 sideIndicators::update        }, //side blinker brightness
    { "cooling",        nullptr,                 cooling::update               }, //occupant fans, radiator fan/pump
    { "lpOutputs",      lpOutputs::init,         lpOutputs::update             }, //app-toggled 12V accessories
    { "soundEffects",   soundEffects::init,      soundEffects::update          }, //MP3 sounds
    { "statusIndicator",nullptr,                 statusIndicator::update       }, //onboard RGB LED
    { "ledStrip",       ledStrip::init,          ledStrip::update              }, //interior neopixel strip
    { "faults",         nullptr,                 faults::update                }, //combine BMS/RMS faults for the dash frame
    { "lightShow",      lightShow::init,         lightShow::update             }, //music light-show bulb accent
    { "canRx",          nullptr,                 canRx::update                 }, //receive + parse CAN frames
    { "canTx",          nullptr,                 canTx::update                 }, //transmit Dash frame
    { "cluster",        nullptr,                 cluster::update               }, //spoof instrument cluster
};

const unsigned kModuleCount = sizeof(kModules) / sizeof(kModules[0]);

} // namespace

namespace modules {

void initAll(){
    for(unsigned i = 0; i < kModuleCount; i++)
        if(kModules[i].init) kModules[i].init();
}

void updateAll(){
    for(unsigned i = 0; i < kModuleCount; i++)
        if(kModules[i].update) kModules[i].update();
}

} // namespace modules
