#pragma once
#include <stdint.h>
/*
 * Inputs - reads every physical switch/ADC once per loop into one struct.
 * Other features read `input.xxx` and never touch pins.
 */
struct InputState {
    bool rightTurn = false;      //right turn stalk
    bool leftTurn  = false;      //left turn stalk
    bool highBeam  = false;      //high beam switch
    bool reverse   = false;      //reverse switch
    bool hazard    = false;      //hazard button
    bool horn      = false;      //horn button
    uint16_t driveADC = 0;           //drive switch (analog or 0/4096)
    uint16_t headlightADC = 0;       //headlight switch (analog or 0/4096)
    uint16_t photoresistorADC = 0;   //ambient light for auto headlights
};
extern InputState input;

namespace inputs {
    void init();     //configure pins + first read
    void update();   //read all pins
}
