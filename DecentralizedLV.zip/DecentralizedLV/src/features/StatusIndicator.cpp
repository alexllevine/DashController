#include "StatusIndicator.h"
#include "BoardLiveness.h"
#include "../Common.h"

namespace statusIndicator {

void update(){
    // Colour = power state
    uint32_t color;
    if(powerController.FullStart)  color = COLOR_BLUE;    //fully started
    else if(powerController.Ign)   color = COLOR_RED;     //ignition, not fully started
    else if(powerController.Acc)   color = COLOR_GREEN;   //accessory
    else                           color = COLOR_WHITE;   //off

    // Pattern = system health (highest-priority condition wins)
    hal::statusLed::Pattern pattern;
    hal::statusLed::Speed   speed;
    if(!liveness::isAlive(BoardId::Power) || !liveness::isAlive(BoardId::HV) || !liveness::isAlive(BoardId::IBooster)){
        speed = hal::statusLed::Speed::Fast;   pattern = hal::statusLed::Pattern::Blink;   //a board went silent
    }
    else if(HVController.Killswitch || HVController.BMSFault){
        speed = hal::statusLed::Speed::Slow;   pattern = hal::statusLed::Pattern::Blink;   //BPS fault
    }
    else if(bms.packStatsReceived && rms.motorTempReceived){
        speed = hal::statusLed::Speed::Normal; pattern = hal::statusLed::Pattern::Fade;    //all data flowing
    }
    else{
        speed = hal::statusLed::Speed::Normal; pattern = hal::statusLed::Pattern::Solid;   //waiting for data
    }

    hal::statusLed::apply(color, pattern, speed);
}

}
