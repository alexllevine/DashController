#include "CanRx.h"
#include "BoardLiveness.h"
#include "LightShow.h"
#include "../Common.h"

namespace canRx {

// ONE place that fans every incoming frame out. To consume a new frame type, add a line below.
void update(){
    CANBusMessage msg;
    while(hal::can::receive(msg)){
        // lastCAN_Received = millis();   // (uncomment if adding a CAN bus timeout detection)
        liveness::onFrame(msg.addr);     //Stamp per-board last-seen time
        vehicle::receiveCan(msg);        //All board objects (power, app, HV, BMS, RMS, iBooster, ...)
        lightShow::onCan(msg);           //Music light-show cues
    }
}

}
