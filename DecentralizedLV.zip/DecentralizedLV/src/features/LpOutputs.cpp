#include "LpOutputs.h"
#include "../Common.h"

// Charger, telemetry radio, ham radio and wiper are app-toggleable low-power MOSFET outputs. Their
// on/off states are persisted by the Power Controller (gateway) and arrive over CAN in
// AppController_CAN, so values here already reflect the saved preference after a power cycle.
namespace lpOutputs {

void init(){
    hal::pinConfig(IPAD_CHARGER, hal::PinConfig::Output);
    hal::pinConfig(TELEMETRY,    hal::PinConfig::Output);
    hal::pinConfig(RADIO,        hal::PinConfig::Output);
    hal::pinConfig(WIPER,        hal::PinConfig::Output);
}

void update(){
    hal::digitalWrite(IPAD_CHARGER, appController.ipadCharger);
    hal::digitalWrite(TELEMETRY,    appController.telemetry);
    hal::digitalWrite(RADIO,        appController.radio);
    hal::digitalWrite(WIPER,        appController.wiper);
}

}
