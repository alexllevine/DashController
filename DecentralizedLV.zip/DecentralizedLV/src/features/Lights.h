#pragma once
namespace lights {
    void update();
    bool leftTurnActive();    //Left signal commanded (switch/app/hazard) - not the flashing state
    bool rightTurnActive();
}
