#pragma once
#include <stdint.h>
namespace sideIndicators {
    void update();
    uint8_t brightness();    //0 = off, 255 = full (flashing for turn signals, solid on fault-drive)
}
