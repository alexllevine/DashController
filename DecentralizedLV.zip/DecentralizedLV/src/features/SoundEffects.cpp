#include "SoundEffects.h"
#include "Faults.h"
#include "Gear.h"
#include "Inputs.h"
#include "../Common.h"

namespace {
    uint32_t initTime = 0;
    bool initialized = false;

    // Edge-detection state: a sound plays only on the transition into a condition
    bool lastFullStart = false;
    bool lastACCharge = false;
    bool lastHornState = false;
    bool lastFaultState = false;
    bool reverseLoopPlaying = false;   //reserved (reverse sound disabled, see end of update())
}

namespace soundEffects {

void init(){
    hal::sound::begin();
    initTime = hal::millis();
}

void update(){
    // Wait for the soundboard before playing anything
    if(hal::millis() - initTime > SOUND_STARTUP_DELAY_MS) initialized = true;
    if(!initialized) return;

    // ===== POWER ON/OFF: on entering / leaving FullStart =====
    if(powerController.FullStart != lastFullStart){
        if(powerController.FullStart){
            hal::sound::play(SOUND_POWER_ON, SOUND_VOL_POWER_ON);
        }
        else{
            hal::sound::play(SOUND_POWER_OFF, SOUND_VOL_POWER_OFF);
            reverseLoopPlaying = false;
        }
        lastFullStart = powerController.FullStart;
    }

    // ===== CHARGER PLUGGED IN =====
    if(powerController.ACCharge != lastACCharge){
        if(powerController.ACCharge) hal::sound::play(SOUND_CHARGER, SOUND_VOL_CHARGER);
        lastACCharge = powerController.ACCharge;
    }

    // ===== HORN: physical button, app command, or power-controller horn relay =====
    bool hornActive = input.horn || appController.horn || powerController.Horn;
    if(hornActive != lastHornState){
        if(hornActive) hal::sound::play(SOUND_HORN, SOUND_VOL_HORN);
        lastHornState = hornActive;
    }

    // ===== FAULT: user tries to drive/reverse with a fault present =====
    bool faultCondition = powerController.FullStart && gear::isDriving() && faults::any();
    if(faultCondition != lastFaultState){
        if(faultCondition) hal::sound::play(SOUND_FAULT, SOUND_VOL_FAULT);
        lastFaultState = faultCondition;
    }

    // Reverse backup sound disabled to avoid blocking delays.
    // No MP3 actions are performed for reverse mode to prevent CAN timing issues.
}

}
