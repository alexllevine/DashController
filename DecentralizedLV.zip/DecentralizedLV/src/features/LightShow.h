#pragma once
#include <stdint.h>
#include "../hal/Hal.h"
/*
 * LightShow - music light-show receiver. The app streams lighting cues (SHOW_* in the board library)
 * which the Power Controller relays onto SHOW_CONTROL_ADDR. This module:
 *   - stores the latest cue per zone (interior strip + running-lights bulb accent)
 *   - strobes the bulb accent itself (update())
 *   - exposes the interior cue for ledstrip/ to render
 * Show mode fully overrides normal lighting while active and FAILS SAFE back to normal lighting if
 * the cue stream stops (SHOW_MODE_TIMEOUT_MS), so a dropped BLE/CAN link always restores normal behavior.
 */
namespace lightShow {
    struct CueState { uint8_t r, g, b, intensity, effect; };

    void init();
    void onCan(CANBusMessage& msg);    //Feed every received frame (called by canRx)
    void update();                     //Drive the bulb accent (dashController.runningLights)
    bool active();                     //True while a show is running and the stream is fresh

    const CueState& interior();        //Latest interior-zone cue
    uint32_t interiorCueMs();          //millis() when it arrived (for pulse decay)
}
