#pragma once
namespace faults {
    void update();   //Combine fault sources into the flags the Dash frame transmits
    bool bps();      //Real BPS/system fault: killswitch, BMS fault, dash-relayed BMS/RMS fault
    bool any();      //bps() OR the reserved corner-board flags (switchFault / bmsFault)
}
