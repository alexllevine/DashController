#pragma once
namespace lpOutputs {
    void init();
    void update();
}
