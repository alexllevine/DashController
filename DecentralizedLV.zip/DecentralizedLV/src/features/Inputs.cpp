#include "Inputs.h"
#include "../Common.h"

InputState input;

namespace inputs {

void init(){
    // Headlight & high-beam switches are active-high (switch applies a voltage). They MUST be pulled
    // down so OFF reads a solid LOW; as plain INPUTs they float and energizing one switch line
    // cross-couples into the other (turning on either appeared to turn on BOTH). In analog headlight
    // mode A1 stays a plain INPUT so the pulldown doesn't load the external resistor network.
    if(DO_ANALOG_LIGHT_SW) hal::pinConfig(HEADLIGHT, hal::PinConfig::Input);
    else                   hal::pinConfig(HEADLIGHT, hal::PinConfig::InputPulldown);
    hal::pinConfig(DRV_SW,     hal::PinConfig::Input);
    hal::pinConfig(HIGHBEAM,   hal::PinConfig::InputPulldown);
    hal::pinConfig(LTURN,      hal::PinConfig::Input);
    hal::pinConfig(RTURN,      hal::PinConfig::Input);
    hal::pinConfig(REV_SW,     hal::PinConfig::Input);
    hal::pinConfig(HAZARD_SW,  hal::PinConfig::Input);
    hal::pinConfig(HORN_SW,    hal::PinConfig::Input);
    hal::pinConfig(LIGHT_SENSE,hal::PinConfig::Input);

    update();   //Get the initial reading of the switches
}

void update(){
    //Headlight: analog voltage via series resistor (auto = 40k/6V, manual = none/12V) or plain binary
    if(DO_ANALOG_LIGHT_SW) input.headlightADC = hal::analogRead(HEADLIGHT);
    else                   input.headlightADC = 4096 * hal::digitalRead(HEADLIGHT);

    //Drive mode: analog (sport = 20k/9V, eco = 40k/6V) or plain binary
    if(DO_ANALOG_DRIVE_SW) input.driveADC = hal::analogRead(DRV_SW);
    else                   input.driveADC = 4096 * hal::digitalRead(DRV_SW);

    input.highBeam  = hal::digitalRead(HIGHBEAM);
    input.leftTurn  = hal::digitalRead(LTURN);
    input.rightTurn = hal::digitalRead(RTURN);
    input.reverse   = hal::digitalRead(REV_SW);
    input.hazard    = hal::digitalRead(HAZARD_SW);
    input.horn      = hal::digitalRead(HORN_SW);

    input.photoresistorADC = hal::analogRead(LIGHT_SENSE);
}

}
