#pragma once
namespace soundEffects {
    void init();
    void update();
}
