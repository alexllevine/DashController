#include "Lights.h"
#include "Inputs.h"
#include "BoardLiveness.h"
#include "../Common.h"

namespace {

bool g_leftActive = false;
bool g_rightActive = false;

// Previous manual switch states, for "just turned OFF" edge detection
bool prevManualHeadlight = false;
bool prevManualHighbeam  = false;
bool prevManualLeftTurn  = false;
bool prevManualRightTurn = false;
bool prevManualHazard    = false;

struct ManualSwitches {
    bool headlightOn, autoMode, highbeamOn, leftTurnOn, rightTurnOn, hazardOn;
};

ManualSwitches readManualSwitches(){
    ManualSwitches m;
    m.headlightOn = (input.headlightADC > HDL_MANU_THR);
    m.autoMode    = (input.headlightADC > HDL_AUTO_THR && input.headlightADC <= HDL_MANU_THR);
    m.highbeamOn  = input.highBeam;
    m.leftTurnOn  = input.leftTurn;
    m.rightTurnOn = input.rightTurn;
    m.hazardOn    = input.hazard || (input.leftTurn && input.rightTurn);   //both stalks = hazards
    return m;
}

// Priority: Manual ON > Auto Mode > App Control (only when manual is completely OFF).
// When the manual switch turns OFF the app's requested state is cleared to prevent feedback loops.
void updateHeadlight(const ManualSwitches& m){
    if(m.headlightOn){
        dashController.headlight = true;
        appController.headlight = true;     //sync app state
    }
    else if(m.autoMode){
        //Auto-headlights from photoresistor (hysteresis: AUTO_HDL_OFF > AUTO_HDL_ON)
        if(dashController.headlight && input.photoresistorADC < AUTO_HDL_OFF){
            dashController.headlight = false;
            appController.headlight = false;
        }
        else if(!dashController.headlight && input.photoresistorADC > AUTO_HDL_ON){
            dashController.headlight = true;
            appController.headlight = true;
        }
    }
    else{
        if(prevManualHeadlight && !m.headlightOn){
            appController.headlight = false;   //manual just turned OFF: clear app's requested state
        }
        dashController.headlight = (appController.usingAppControl && appController.headlight);
    }
    prevManualHeadlight = m.headlightOn;
}

void updateHighBeam(const ManualSwitches& m){
    if(!powerController.LowPowerMode){
        if(m.highbeamOn){
            dashController.highbeam = true;
            appController.highbeam = true;
        }
        else{
            if(prevManualHighbeam && !m.highbeamOn){
                appController.highbeam = false;   //manual just turned OFF: clear app state
            }
            dashController.highbeam = (appController.usingAppControl && appController.highbeam);
        }
    }
    else{
        dashController.highbeam = false;
        appController.highbeam = false;
    }
    prevManualHighbeam = m.highbeamOn;
}

void updateTurnSignals(const ManualSwitches& m){
    bool flash = hal::millis() % 1000 < 500;   //1 Hz flash
    bool leftSignalOn = false;
    bool rightSignalOn = false;

    //Hazards: physical button, app command, OR both turn signals pressed
    bool hazardsRequested = m.hazardOn || (appController.usingAppControl && appController.hazards);

    if(hazardsRequested){
        leftSignalOn = true;
        rightSignalOn = true;
        appController.hazards = true;
        appController.leftTurnSignal = true;
        appController.rightTurnSignal = true;
    }
    else{
        appController.hazards = false;   //hazards no longer requested (covers manual-just-turned-off too)

        //Left
        if(m.leftTurnOn){
            leftSignalOn = true;
            appController.leftTurnSignal = true;
        }
        else{
            if(prevManualLeftTurn && !m.leftTurnOn) appController.leftTurnSignal = false;
            leftSignalOn = (appController.usingAppControl && appController.leftTurnSignal);
        }

        //Right
        if(m.rightTurnOn){
            rightSignalOn = true;
            appController.rightTurnSignal = true;
        }
        else{
            if(prevManualRightTurn && !m.rightTurnOn) appController.rightTurnSignal = false;
            rightSignalOn = (appController.usingAppControl && appController.rightTurnSignal);
        }
    }

    prevManualLeftTurn  = m.leftTurnOn;
    prevManualRightTurn = m.rightTurnOn;
    prevManualHazard    = m.hazardOn;

    dashController.leftTurnPWM  = (leftSignalOn  && flash) ? 255 : 0;
    dashController.rightTurnPWM = (rightSignalOn && flash) ? 255 : 0;

    g_leftActive  = leftSignalOn;
    g_rightActive = rightSignalOn;
}

// Horn is momentary - no edge detection needed, it auto-clears when released.
void updateHorn(){
    if(input.horn || powerController.Horn){
        appController.horn = true;
    }
    else if(!appController.usingAppControl){
        appController.horn = false;
    }
}

} // namespace

namespace lights {

void update(){
    // App-control staleness: usingAppControl latches on the last AppController (0x101) frame and is
    // never cleared when the app goes silent, so app-requested states can stay stuck on.
    // TODO: gate the appController.usingAppControl branches above on !appControlStale. Unblocked now
    //       that the Dash no longer transmits 0x101 (that caused a two-transmitter CAN conflict).
    bool appControlStale = !liveness::isAlive(BoardId::AppController);
    (void)appControlStale;

    ManualSwitches m = readManualSwitches();

    updateHeadlight(m);
    updateHighBeam(m);
    updateTurnSignals(m);
    updateHorn();

    // Eyes mode: app-only novelty feature, no manual control, never persisted. Only honored while the
    // app is connected so it can't get stuck on (appController.initialize() also clears it on boot).
    dashController.eyesMode = appController.usingAppControl && appController.eyesMode;

    dashController.reversePress = (dashController.driveMode == DRIVE_MODE_REVERSE);
}

bool leftTurnActive()  { return g_leftActive; }
bool rightTurnActive() { return g_rightActive; }

}
