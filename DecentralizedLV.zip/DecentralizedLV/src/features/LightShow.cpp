#include "LightShow.h"
#include "../Common.h"

namespace {
    ShowController_CAN showController(SHOW_CONTROL_ADDR);
    lightShow::CueState showInterior = {0, 0, 0, 0, 0};   //latest zone-0 (interior) cue
    lightShow::CueState showBulbs    = {0, 0, 0, 0, 0};   //latest zone-5 cue; colour ignored by the bulb output
    bool     showModeOn = false;       //latest showActive flag received
    uint32_t showLastMsgMs = 0;        //millis() of last show frame heard (any zone)
    uint32_t showInteriorCueMs = 0;    //millis() of last interior cue (pulse decay)
    uint32_t showBulbCueMs = 0;        //millis() of last bulb cue (local envelope timing)
}

namespace lightShow {

void init(){ showController.initialize(); }

// Each frame targets one zone; demux the two zones this board renders.
void onCan(CANBusMessage& msg){
    showController.receiveCANData(msg);
    if(showController.freshCue){
        showController.freshCue = false;
        showModeOn = showController.showActive;
        showLastMsgMs = hal::millis();
        if(showController.zone == SHOW_ZONE_INTERIOR){
            showInterior.r = showController.red;
            showInterior.g = showController.green;
            showInterior.b = showController.blue;
            showInterior.intensity = showController.intensity;
            showInterior.effect = showController.effect;
            showInteriorCueMs = hal::millis();
        } else if(showController.zone == SHOW_ZONE_BULBS){
            showBulbs.r = showController.red;
            showBulbs.g = showController.green;
            showBulbs.b = showController.blue;
            showBulbs.intensity = showController.intensity;
            showBulbs.effect = showController.effect;
            showBulbCueMs = hal::millis();
        }
    }
}

// Fails safe: no cue for SHOW_MODE_TIMEOUT_MS (dropped link / app stopped) -> false -> normal lighting.
bool active(){
    return showModeOn && (hal::millis() - showLastMsgMs < SHOW_MODE_TIMEOUT_MS);
}

// Render the bulb-zone cue through the binary running-lights output: effects become temporal envelopes.
// Intentionally never touches the main headlight/highbeam outputs.
void update(){
    if(!active()) return;

    uint32_t elapsed = hal::millis() - showBulbCueMs;
    bool accentOn = false;
    switch(showBulbs.effect){
        case SHOW_FX_SOLID:
            accentOn = showBulbs.intensity > 0;
            break;
        case SHOW_FX_PULSE:
            //Visible long enough to read, naturally expires without a new cue
            accentOn = elapsed < (80 + ((uint32_t)showBulbs.intensity * 220 / 255));
            break;
        case SHOW_FX_STROBE:
            accentOn = showBulbs.intensity > 0 && ((elapsed / 75) % 2 == 0);
            break;
        case SHOW_FX_CHASE:
        case SHOW_FX_RIPPLE:
        case SHOW_FX_THEATER_CHASE:
        case SHOW_FX_SPARKLE:
        case SHOW_FX_SWEEP:
        default:
            //Bulbs can't animate spatially: use a strong 4 Hz accent
            accentOn = showBulbs.intensity > 0 && (elapsed % 250 < 125);
            break;
    }
    dashController.runningLights = accentOn;
}

const CueState& interior(){ return showInterior; }
uint32_t interiorCueMs(){ return showInteriorCueMs; }

}
