#pragma once
namespace statusIndicator {
    void update();   //Onboard RGB LED: colour = power state, pattern = health
}
