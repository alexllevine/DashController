#pragma once
namespace cluster { void update(); }   //Spoof Camry instrument cluster CAN frames (airbag/ABS lights off, gauges, icons)
