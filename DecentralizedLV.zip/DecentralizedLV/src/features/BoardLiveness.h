#pragma once
#include <stdint.h>
/*
 * BoardLiveness - "is this CAN board still talking?" Table driven.
 * Add a board: add an enum entry here + a matching row in BoardLiveness.cpp (same order).
 */
enum class BoardId : uint8_t { Power, HV, IBooster, AppController, Count };

namespace liveness {
    void onFrame(uint32_t canAddr);     //Call for every received frame
    bool isAlive(BoardId id);           //True if heard within BOARD_ONLINE_TIMEOUT_MS
}
