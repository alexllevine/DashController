#include "BoardLiveness.h"
#include "../Common.h"

namespace {
    struct Entry { uint32_t addr; uint32_t lastSeenMs; };

    // Order MUST match enum BoardId. lastSeenMs == 0 means "never heard".
    Entry table[] = {
        { POWER_CONTROL_ADDR, 0 },   //PowerController  (0x120)
        { HV_CONTROL_ADDR,    0 },   //HVController     (0x130)
        { IBOOSTER_ADDR,      0 },   //iBooster         (0x214)
        { APPCONTROL_ADDR,    0 },   //AppController    (0x101)
    };
    static_assert(sizeof(table)/sizeof(table[0]) == (size_t)BoardId::Count, "table must match BoardId");
}

namespace liveness {

// Stamp the board's last-seen time. Replaces a one-shot "detected" latch which read "present"
// forever even if the board later went silent.
void onFrame(uint32_t canAddr){
    for(auto& e : table)
        if(e.addr == canAddr){ e.lastSeenMs = hal::millis(); break; }
}

bool isAlive(BoardId id){
    uint32_t last = table[(uint8_t)id].lastSeenMs;
    if(last == 0) return false;   //never seen
    return (hal::millis() - last) <= BOARD_ONLINE_TIMEOUT_MS;
}

}
