#include "RunningLights.h"
#include "../Common.h"

// App-toggleable preference, persisted across reboots. The Dash Controller is the source of truth:
// the app can request a change, but the persisted/broadcast state here is what gets displayed.
#define RUNNING_LIGHTS_STORAGE_ADDR  0              //Dash has not used EEPROM before this feature - safe at 0
#define RUNNING_LIGHTS_MAGIC         0x524C4331     //"RLC1" - marks the slot as holding a valid preference

namespace {
    bool preference = true;   //Persisted on/off preference. Defaults ON until a value is loaded/changed.

    void load(){
        uint32_t magic = 0;
        hal::storageGet(RUNNING_LIGHTS_STORAGE_ADDR, magic);
        if(magic == RUNNING_LIGHTS_MAGIC){
            bool stored = true;
            hal::storageGet(RUNNING_LIGHTS_STORAGE_ADDR + sizeof(uint32_t), stored);
            preference = stored;
        }
        else{
            preference = true;   //Never been set before - default ON
        }
    }

    void save(){
        uint32_t magic = RUNNING_LIGHTS_MAGIC;
        hal::storagePut(RUNNING_LIGHTS_STORAGE_ADDR, magic);
        hal::storagePut(RUNNING_LIGHTS_STORAGE_ADDR + sizeof(uint32_t), preference);
    }
}

namespace runningLights {

void init(){ load(); }

void update(){
    // While the app is connected it owns the preference: whatever it requests becomes the new
    // persisted value (written so it survives a reboot even after the app disconnects). When the app
    // is NOT connected we hold the last persisted preference - a rebooted, app-less gateway
    // broadcasting its default can't stomp it because usingAppControl is false in that case.
    // (Level-triggered on purpose: an earlier edge-detected scheme deadlocked a persisted "off".)
    if(appController.usingAppControl && appController.runningLights != preference){
        preference = appController.runningLights;
        save();
    }

    bool carPowered = powerController.Acc || powerController.Ign || powerController.FullStart;
    dashController.runningLights = preference && carPowered;
}

}
