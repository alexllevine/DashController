#pragma once
namespace canTx { void update(); }
