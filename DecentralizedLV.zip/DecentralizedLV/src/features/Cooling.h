#pragma once
#include <stdint.h>
namespace cooling {
    void update();
    uint8_t tempToPWM(float tempC, float tempOn, float tempFull);   //linear map: 0 below tempOn, 255 at/above tempFull
}
