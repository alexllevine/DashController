#include "Cluster.h"
#include "BoardLiveness.h"
#include "../Common.h"

namespace cluster {

void update(){
    //Drive mode shown
    instrumentCluster.driveMode = dashController.driveMode;
    instrumentCluster.ecoMode = powerController.LowPowerMode;   //Eco text at bottom of screen (not the ECO leaf)

    //Lights. Backlight dims if headlights are on
    instrumentCluster.headlight = dashController.headlight;
    instrumentCluster.highbeam = dashController.highbeam;
    if(dashController.headlight) instrumentCluster.LCD_Brightness = LCD_BRIGHTNESS_LOW;
    else instrumentCluster.LCD_Brightness = LCD_BRIGHTNESS_HIGH;

    //BMS faults: "Hybrid System Stopped" on BMS fault
    if(dashController.bmsFaultDetected) instrumentCluster.LCD_PowerPrompt = LCD_HYBRID_SYSTEM_STOPPED;
    else if(powerController.Acc && !powerController.FullStart) instrumentCluster.LCD_PowerPrompt = LCD_IGNITION_PROMPT;
    else instrumentCluster.LCD_PowerPrompt = LCD_POWER_GOOD;

    //12V battery status, if low
    instrumentCluster.chargingSystemMalfunction = powerController.LowACCBattery;

    //Parking brake (future: read a corner board, show when brake on in "Drive")
    instrumentCluster.parkingBrakeCircle = false;
    instrumentCluster.LCD_ParkingBrakePrompt = LCD_PBRK_GOOD;

    //iBooster detection: red BRAKE text when it is missing (times out if it goes silent)
    instrumentCluster.brakeIcon = !liveness::isAlive(BoardId::IBooster);

    //RMS fault information
    if(dashController.rmsFaultDetected && !dashController.bmsFaultDetected) instrumentCluster.LCD_EngineStoppedCode = LCD_ENGINE_STOPPED;
    else instrumentCluster.LCD_EngineStoppedCode = LCD_ENGINE_NORMAL;
    instrumentCluster.checkEngineOn = dashController.rmsFaultDetected;

    instrumentCluster.readyToDrive = powerController.FullStart;   //Park icon on cluster

    instrumentCluster.trunkOpen = false;   //Future: corner board with a trunk switch

    //RPM and speed gauges
    instrumentCluster.rpmGauge = rms.motorRPM;              //Future: use a sensor (only works when throttle applied)
    instrumentCluster.speedGauge = rms.motorRPM / 68.5;     //Poor estimation of speed from RPM

    //Motor temperature from the RMS
    instrumentCluster.motorTempDegC = rms.motorTemperatureC;

    //Economy rating from battery current (250 A -> 0 %, 0 A -> 100 %)
    int batteryCurrent = bms.packCurrentAmps;
    float ecoPercentage = batteryCurrent / 2.5;
    if(ecoPercentage > 100) ecoPercentage = 100;
    else if(ecoPercentage < 0) ecoPercentage = 0;
    ecoPercentage = 100 - ecoPercentage;
    instrumentCluster.ecoGauge = ecoPercentage;
    instrumentCluster.ecoLeaf = (bms.packCurrentAmps < 2);   //Leaf when idle/charging (e.g. solar)

    //"Outdoor" temperature slot shows the battery pack temp (a good battery-temp approximation)
    instrumentCluster.outsideTemperatureF = (bms.thermistorLowTempC * 1.8) + 32;

    //Send - the object handles every variable automatically
    instrumentCluster.sendCANData(hal::can::controller());
}

}
