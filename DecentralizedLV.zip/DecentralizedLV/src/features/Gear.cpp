#include "Gear.h"
#include "Inputs.h"
#include "../Common.h"

namespace gear {

void update(){
    if(powerController.FullStart){  //Power controller says user fully started the car (brake + PTS)
        if(input.reverse) dashController.driveMode = DRIVE_MODE_REVERSE;
        else if(input.driveADC > DRV_SPT_THR && input.driveADC < DRV_NRM_THR) dashController.driveMode = DRIVE_MODE_SPORT;
        else if(input.driveADC > DRV_ECO_THR && input.driveADC < DRV_SPT_THR) dashController.driveMode = DRIVE_MODE_ECO;
        else if(input.driveADC > DRV_NRM_THR) dashController.driveMode = DRIVE_MODE_FORWARD;
        else dashController.driveMode = DRIVE_MODE_PARK;
        if(dashController.driveMode != DRIVE_MODE_PARK && (bmsFault || switchFault)) dashController.driveMode = DRIVE_MODE_NEUTRAL;
    }
}

bool isDriving(){
    return dashController.driveMode == DRIVE_MODE_FORWARD ||
           dashController.driveMode == DRIVE_MODE_REVERSE ||
           dashController.driveMode == DRIVE_MODE_SPORT   ||
           dashController.driveMode == DRIVE_MODE_ECO;
}

}
