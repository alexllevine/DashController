#pragma once
namespace gear {
    void update();       //Pick drive mode from the switches (only while fully started)
    bool isDriving();    //True in Forward/Reverse/Sport/Eco (i.e. "trying to move")
}
