#include "SideIndicators.h"
#include "Faults.h"
#include "Gear.h"
#include "Lights.h"
#include "../Common.h"

namespace {
    uint32_t turnSignalLastToggle = 0;   //Time of last flash toggle
    bool     turnSignalFlashing = false; //Current flash state (ON/OFF)
    uint8_t  sideBrightness = 0;         //0=off, 255=full bright

    // Reserved controls for a future app-driven brightness mode
    bool    sideIndicatorsAutomatic = true;   //Car controls brightness automatically
    uint8_t sideIndicatorManualBrightness = 255;
}

namespace sideIndicators {

void update(){
    // Trying to drive with a BPS fault: solid on
    bool tryingToDriveWithFault = powerController.FullStart && faults::bps() && gear::isDriving();
    if(tryingToDriveWithFault){
        sideBrightness = 255;
        return;
    }

    if(lights::leftTurnActive() || lights::rightTurnActive()){
        uint32_t timeSinceToggle = hal::millis() - turnSignalLastToggle;
        if(timeSinceToggle >= TURN_SIGNAL_HALF_PERIOD_MS){   //toggle each half period
            turnSignalFlashing = !turnSignalFlashing;
            turnSignalLastToggle = hal::millis();
        }
        sideBrightness = turnSignalFlashing ? 255 : 0;
    }
    else{
        sideBrightness = 0;   //no turn signals active
    }
}

uint8_t brightness(){ return sideBrightness; }

}
