#include "Faults.h"
#include "../Common.h"

namespace faults {

// SINGLE definition of "a fault is present" - used by the LED strip, side indicators and sound.
// Board-detection (CAN heartbeat) loss is deliberately NOT a fault source: a missing board makes
// the Dash unhappy (fast onboard LED blink) but must not masquerade as a BPS fault on the cluster.
bool bps(){
    return HVController.BMSFault || HVController.Killswitch ||
           dashController.bmsFaultDetected || dashController.rmsFaultDetected;
}

bool any(){
    return bps() || switchFault || bmsFault;
}

void update(){
    dashController.bmsFaultDetected = HVController.BMSFault || HVController.Killswitch;
    dashController.rmsFaultDetected = rms.faultActive;
}

}
