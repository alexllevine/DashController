#include "Cooling.h"
#include "../Common.h"

namespace cooling {

uint8_t tempToPWM(float tempC, float tempOn, float tempFull){
    if(tempC < tempOn) return 0;
    if(tempC >= tempFull) return 255;
    return (uint8_t)(255.0f * (tempC - tempOn) / (tempFull - tempOn));
}

void update(){
    // Occupant-cell (front cabin) fans: speed set by the app (AppController_CAN.occupantFanPWM), relayed
    // in the Dash frame; the front-right LPDRV board (BDFR, LP6) drives the MOSFET. Only while on.
    if(powerController.Acc || powerController.Ign){
        dashController.occupantFanPWM = appController.occupantFanPWM;
    } else {
        dashController.occupantFanPWM = 0;
    }

    // Radiator / motor-cooling fan and pump.
    // NOTE: Battery-box fans are driven autonomously by the HV Controller (output on BDFL LP6) - not here.
    if(powerController.Ign){
        if(DO_RMS_FAN_CONTROL && rms.motorTempReceived){
            uint8_t radPWM = tempToPWM(rms.motorTemperatureC, RAD_FAN_TEMP_ON, RAD_FAN_TEMP_FULL);
            dashController.radiatorFanPWM = radPWM;
            dashController.radiatorPump = (radPWM > 0);
        } else {
            dashController.radiatorFanPWM = 255;   //Default: run radiator whenever ignition is on
            dashController.radiatorPump = true;
        }
    } else {
        dashController.radiatorFanPWM = 0;
        dashController.radiatorPump = false;
    }
}

}
