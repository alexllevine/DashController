#pragma once
namespace canRx { void update(); }   //Drain the CAN RX queue and hand each frame to every consumer
