#pragma once
namespace runningLights {
    void init();     //Load persisted preference
    void update();   //Sync with app + drive dashController.runningLights
}
