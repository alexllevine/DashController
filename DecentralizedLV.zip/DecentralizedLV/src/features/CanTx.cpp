#include "CanTx.h"
#include "../Common.h"

namespace canTx {

void update(){
    dashController.sendCANData(hal::can::controller());
    // The Dash does NOT transmit the AppController frame (0x101). That frame is the app->car command
    // channel, transmitted solely by the Power Controller (BLE gateway); every board - including this
    // one - only RECEIVES it. Previously the Dash also echoed 0x101, which put TWO nodes on one CAN ID:
    // frames collided during arbitration, generated error frames, and intermittently dropped the Power
    // Controller's real command frame (this made the app's interior-strip brightness unreliable). The
    // app already gets control + telemetry state from the Power Controller, so the echo was redundant.
}

}
