/*
 * Project DecentralizedLV - Dash Controller
 *
 * This file is intentionally tiny. All behaviour lives in features/ and ledstrip/,
 * all hardware access lives in hal/, all tunables live in config/.
 * See modules/Modules.cpp for the list (and order) of everything that runs.
 */
#include "Common.h"
#include "modules/Modules.h"

#if PLATFORM_PARTICLE
SYSTEM_MODE(SEMI_AUTOMATIC);
#endif

static uint32_t loop_time = 0;   //Loop has a fixed period but no overflow protection
                                 //TO DO: Implement Watchdog Timer

// setup() runs once, when the device is first turned on.
void setup() {
    hal::debugBegin(115200);
    modules::initAll();
}

// loop() runs over and over again.
void loop() {
    modules::updateAll();

    //Hold the loop to a fixed period
    while(hal::millis() - loop_time < LOOP_PERIOD_MS) hal::delayMicros(1);
    loop_time = hal::millis();
}
