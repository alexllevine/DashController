#pragma once
#include "../hal/Hal.h"
/*
 * Vehicle.h - the shared "world model": one object per CAN board this controller talks to.
 * Features READ/WRITE these (e.g. dashController.headlight = true). Add a new board here in 3 steps:
 *   1. extern declaration below   2. definition in Vehicle.cpp   3. init + receive lines in Vehicle.cpp
 */
extern DashController_CAN   dashController;     //Frame THIS board transmits
extern LPDRV_RearLeft_CAN   rearLeftDriver;
extern PowerController_CAN  powerController;
extern AppController_CAN    appController;      //App->car command channel (RX only here)
extern CamryCluster_CAN     instrumentCluster;  //Spoofed instrument cluster frames
extern HVController_CAN     HVController;
extern IBOOSTER_CAN         iBooster;
extern OrionBMS             bms;
extern RMSController        rms;

//Values received from corner boards (reserved: nothing sets these yet)
extern bool switchFault;    //kill switch opened
extern bool bmsFault;       //BMS fault

namespace vehicle {
    void init();                          //Start CAN + initialise every board object
    void receiveCan(CANBusMessage& msg);  //Feed one incoming frame to every board object
}
