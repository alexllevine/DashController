#include "Vehicle.h"
#include "../config/Config.h"

DashController_CAN  dashController(DASH_CONTROL_ADDR);
LPDRV_RearLeft_CAN  rearLeftDriver(REAR_LEFT_DRIVER);
PowerController_CAN powerController(POWER_CONTROL_ADDR);
AppController_CAN   appController(APPCONTROL_ADDR);
CamryCluster_CAN    instrumentCluster;
HVController_CAN    HVController(HV_CONTROL_ADDR);
IBOOSTER_CAN        iBooster(IBOOSTER_ADDR);
OrionBMS            bms(ORION_PACK_STAT_ADDR, ORION_DTC_CELLV_ADDR, ORION_CUR_LMT_TEMP_ADDR, ORION_J1772_STATS_ADDR);
RMSController       rms(RMS_POWER_STAT_ADDR, RMS_MTR_TEMP_ADDR, RMS_POST_FAULTS_ADDR);

bool switchFault = false;
bool bmsFault    = false;

namespace vehicle {

void init(){
    hal::can::begin(CAN_BAUD_RATE);
    // Hardware CAN filters are NOT used: we exceed the filter count, so all messages are accepted.
    // (Previously: addFilter for powerController, rearLeftDriver, ORION_PACK_STAT_ADDR, ORION_DTC_CELLV_ADDR)

    // Set every variable this board transmits to its default value
    dashController.initialize();
    powerController.initialize();
    appController.initialize();
    rearLeftDriver.initialize();
    instrumentCluster.initialize();
    HVController.initialize();
    iBooster.initialize();
}

void receiveCan(CANBusMessage& msg){
    powerController.receiveCANData(msg);
    appController.receiveCANData(msg);   //App->car commands relayed by the Power Controller gateway
    rearLeftDriver.receiveCANData(msg);
    HVController.receiveCANData(msg);
    bms.receiveCANData(msg);
    rms.receiveCANData(msg);
    iBooster.receiveCANData(msg);
}

} // namespace vehicle
