// Particle backend: time, GPIO, random, storage, debug, status LED, CAN.
#include "../Platform.h"
#if PLATFORM_PARTICLE
#include "../Hal.h"

namespace hal {

uint32_t millis()                    { return ::millis(); }
void     delayMicros(uint32_t us)    { ::delayMicroseconds(us); }

void pinConfig(Pin pin, PinConfig cfg){
    switch(cfg){
        case PinConfig::Input:         ::pinMode(pin, INPUT);          break;
        case PinConfig::InputPulldown: ::pinMode(pin, INPUT_PULLDOWN); break;
        case PinConfig::Output:        ::pinMode(pin, OUTPUT);         break;
    }
}
bool     digitalRead(Pin pin)            { return ::digitalRead(pin) != 0; }
void     digitalWrite(Pin pin, bool v)   { ::digitalWrite(pin, v ? HIGH : LOW); }
uint16_t analogRead(Pin pin)             { return (uint16_t)::analogRead(pin); }

uint32_t random(uint32_t maxExclusive)                        { return (uint32_t)::random((int32_t)maxExclusive); }
uint32_t random(uint32_t minInclusive, uint32_t maxExclusive) { return (uint32_t)::random((int32_t)minInclusive, (int32_t)maxExclusive); }

void storageRead(uint16_t addr, void* dst, size_t len){
    uint8_t* p = (uint8_t*)dst;
    for(size_t i = 0; i < len; i++) p[i] = EEPROM.read(addr + i);
}
void storageWrite(uint16_t addr, const void* src, size_t len){
    const uint8_t* p = (const uint8_t*)src;
    for(size_t i = 0; i < len; i++){
        if(EEPROM.read(addr + i) != p[i]) EEPROM.write(addr + i, p[i]);   //skip unchanged bytes (flash wear)
    }
}

void debugBegin(uint32_t baud){ Serial.begin(baud); }

namespace statusLed {
    static LEDStatus s_status;
    void apply(uint32_t rgb, Pattern pattern, Speed speed){
        s_status.setColor(rgb);
        switch(speed){
            case Speed::Slow:   s_status.setSpeed(LED_SPEED_SLOW);   break;
            case Speed::Normal: s_status.setSpeed(LED_SPEED_NORMAL); break;
            case Speed::Fast:   s_status.setSpeed(LED_SPEED_FAST);   break;
        }
        switch(pattern){
            case Pattern::Solid: s_status.setPattern(LED_PATTERN_SOLID); break;
            case Pattern::Blink: s_status.setPattern(LED_PATTERN_BLINK); break;
            case Pattern::Fade:  s_status.setPattern(LED_PATTERN_FADE);  break;
        }
        s_status.setActive(true);   //Take over from Particle's default LED scheme
    }
}

namespace can {
    static PhotonCANController s_can;
    void        begin(uint32_t baud)         { s_can.begin(baud); }
    bool        receive(CANBusMessage& msg)  { return s_can.receive(msg); }
    Controller& controller()                 { return s_can; }
}

} // namespace hal
#endif
