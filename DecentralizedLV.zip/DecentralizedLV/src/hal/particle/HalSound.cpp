// Particle backend: GD3300 MP3 soundboard on Serial1.
#include "../Platform.h"
#if PLATFORM_PARTICLE
#include "GD3300.h"
#include "../Hal.h"

namespace hal { namespace sound {
    static GD3300 s_mp3;

    void begin(){
        Serial1.begin(9600);
        s_mp3.begin(Serial1);
        s_mp3.sendCommand(CMD_SEL_DEV, 0, 2);   //select SD card
    }
    void play(uint8_t track, uint8_t volume){ s_mp3.playWithVolume(track, volume); }
}}
#endif
