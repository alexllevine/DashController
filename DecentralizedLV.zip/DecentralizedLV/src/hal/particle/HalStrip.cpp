// Particle backend: WS281x pixel strip via the neopixel library.
#include "../Platform.h"
#if PLATFORM_PARTICLE
#include "neopixel.h"
#include "../Hal.h"

namespace hal { namespace strip {
    static Adafruit_NeoPixel* s_px = nullptr;

    void begin(uint16_t count, Pin dataPin){
        if(!s_px) s_px = new Adafruit_NeoPixel(count, dataPin, WS2813);   //WS2815 strip uses the WS2813 protocol
        s_px->begin();
    }
    void setBrightness(uint8_t b){ if(s_px) s_px->setBrightness(b); }
    void clear()                 { if(s_px) s_px->clear(); }
    void show()                  { if(s_px) s_px->show(); }
    void setPixel(uint16_t i, uint8_t r, uint8_t g, uint8_t b){ if(s_px) s_px->setPixelColor(i, r, g, b); }
    uint32_t getPixel(uint16_t i){ return s_px ? s_px->getPixelColor(i) : 0; }
}}
#endif
