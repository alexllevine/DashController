#pragma once
/*
 * Hal.h - Hardware Abstraction Layer. THE ONLY interface features use to touch hardware.
 * Features never call digitalRead/millis/EEPROM/Serial/NeoPixel/etc. directly.
 * Implementations live in hal/<platform>/.
 */
#include <stdint.h>
#include <stddef.h>
#include "Platform.h"

// Library headers (order preserved from the original sketch). CANBusMessage lives here.
#include "DecentralizedLV-Boards/DecentralizedLV.h"
#include "DecentralizedLV-Boards/HVBoards/DecentralizedLV-HVBoards.h"
#if PLATFORM_PARTICLE
  #include "DecentralizedLV-Boards/PlatformSupport/Particle/PhotonCANController.h"
#endif

namespace hal {

using Pin = uint16_t;
enum class PinConfig : uint8_t { Input, InputPulldown, Output };

// ---- Time ----
uint32_t millis();
void     delayMicros(uint32_t us);

// ---- GPIO ----
void     pinConfig(Pin pin, PinConfig cfg);
bool     digitalRead(Pin pin);
void     digitalWrite(Pin pin, bool value);
uint16_t analogRead(Pin pin);            //Raw ADC counts (12-bit on Photon)

// ---- Random ----
uint32_t random(uint32_t maxExclusive);
uint32_t random(uint32_t minInclusive, uint32_t maxExclusive);

// ---- Persistent storage (EEPROM / flash emulation) ----
void storageRead(uint16_t addr, void* dst, size_t len);
void storageWrite(uint16_t addr, const void* src, size_t len);
template<typename T> inline void storageGet(uint16_t addr, T& v)       { storageRead(addr, &v, sizeof(T)); }
template<typename T> inline void storagePut(uint16_t addr, const T& v) { storageWrite(addr, &v, sizeof(T)); }

// ---- Debug serial ----
void debugBegin(uint32_t baud);

// ---- Onboard status LED ----
namespace statusLed {
    enum class Pattern : uint8_t { Solid, Blink, Fade };
    enum class Speed   : uint8_t { Slow, Normal, Fast };
    void apply(uint32_t rgb, Pattern pattern, Speed speed);
}

// ---- CAN bus ----
namespace can {
    #if PLATFORM_PARTICLE
    using Controller = PhotonCANController;   //Type the board library classes send/receive through
    #endif
    void        begin(uint32_t baud);
    bool        receive(CANBusMessage& msg); //false when the RX queue is empty
    Controller& controller();                //Pass to <board>.sendCANData(...)
}

// ---- Addressable pixel strip ----
namespace strip {
    void     begin(uint16_t count, Pin dataPin);
    void     setBrightness(uint8_t b);
    void     clear();
    void     show();
    void     setPixel(uint16_t i, uint8_t r, uint8_t g, uint8_t b);
    uint32_t getPixel(uint16_t i);
}

// ---- MP3 soundboard ----
namespace sound {
    void begin();
    void play(uint8_t track, uint8_t volume);
}

} // namespace hal
