#pragma once
/*
 * Platform.h - choose the HAL backend. To port to another MCU:
 *   1. Add #define PLATFORM_<NAME> 1 (or pass -DPLATFORM_<NAME> in the build)
 *   2. Create hal/<name>/ implementing every function declared in Hal.h
 *   3. Add its framework include below. NO feature code changes.
 */
#if !defined(PLATFORM_PARTICLE)
  #define PLATFORM_PARTICLE 1   //default backend
#endif

#if PLATFORM_PARTICLE
  #include "Particle.h"
#endif
