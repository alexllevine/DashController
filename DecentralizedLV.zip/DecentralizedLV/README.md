# DecentralizedLV - Dash Controller (modular layout)

```
src/
  DecentralizedLV.ino      setup()/loop() only (~20 lines)
  Common.h                 one include for features: HAL + config + vehicle
  config/                  ALL tunables: Config.h (flags/thresholds), Colors.h, Pins.h -> PinMap_<board>.h, CanIds.h
  hal/                     Hardware Abstraction Layer
    Hal.h                  the only hardware API features may use (time, GPIO, storage, CAN, strip, sound, status LED)
    Platform.h             picks the backend
    particle/              Photon implementation of Hal.h
  vehicle/                 shared CAN board objects (dashController, powerController, bms, ...) + RX fan-out
  modules/Modules.cpp      THE registry: one row per feature, row order = run order
  features/                one workflow per file pair (Inputs, Gear, Lights, Cooling, SoundEffects, Cluster, ...)
  ledstrip/                neopixel strip: LedStrip (dispatcher) + Charging / Twinkle / ShowRender / Util
```

## Rules that keep things un-intertwined
1. Features talk to hardware ONLY through `hal::`.
2. Features talk to each other ONLY through (a) the shared board objects in `vehicle/`, (b) `input`, or (c) a tiny
   accessor in the other feature's header (e.g. `faults::bps()`, `gear::isDriving()`, `lights::leftTurnActive()`).
3. Each feature has `init()` / `update()`; the registry calls them. Nothing else calls `update()`.

## "I want to..." -> change exactly this
| Goal | Edit |
|---|---|
| Tweak a threshold, volume, LED count, twinkle, fan temp, flash rate | `config/Config.h` |
| Change a colour | `config/Colors.h` |
| Move a pin / new hardware revision | `config/PinMap_*.h` |
| Change what counts as a "fault" (affects strip, sounds, side indicators) | `features/Faults.cpp` -> `bps()` |
| Change what counts as "driving" | `features/Gear.cpp` -> `isDriving()` |
| Add a feature | new `features/Foo.h/.cpp` + 1 row in `modules/Modules.cpp` |
| Temporarily disable a feature | comment its row in `modules/Modules.cpp` |
| Listen to a new CAN board | `Vehicle.h/.cpp` (declare, define, init, receive) |
| Track a board's online status | `features/BoardLiveness.h/.cpp` (1 enum + 1 table row) |
| Add an LED-strip effect | new function in `ledstrip/`, call it from `LedStrip.cpp::update()` |
| Add a sound | `SOUND_*` in `Config.h` + one `hal::sound::play` in `SoundEffects.cpp` |

## Porting to another MCU / board
* New **board, same MCU**: copy `PinMap_PhotonDash.h`, select it in `config/Pins.h`.
* New **MCU/framework**: add `hal/<name>/` implementing every function in `hal/Hal.h`, add the
  `PLATFORM_<NAME>` branch in `hal/Platform.h` and `Hal.h` (CAN controller type). Feature code is untouched.

## Notes
* Particle builds compile `.cpp` files in nested `src/` folders; all includes are relative so no include-path setup is needed.
* Nothing here has been compiled against the real DecentralizedLV-Boards / neopixel / GD3300 libraries - do a
  `particle compile photon` and fix any member-name typos first.
* `legacy/LEGACY.txt` keeps the commented-out and never-used code from the original sketch.
